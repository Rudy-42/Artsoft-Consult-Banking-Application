export class LoginResponseModel {
  token: string;
  message: string;
}
