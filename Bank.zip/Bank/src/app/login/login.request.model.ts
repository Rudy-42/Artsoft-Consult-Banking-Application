export class LoginRequestModel {
  username: string;
  password: string;
}
