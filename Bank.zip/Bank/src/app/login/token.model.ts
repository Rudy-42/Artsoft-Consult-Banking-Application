export class TokenModel {
  token: string;
  message: string;
}
