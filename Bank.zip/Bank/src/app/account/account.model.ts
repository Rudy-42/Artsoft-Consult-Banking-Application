export class AccountModel {
  id;
  dateOpened;
  balance;
  currency: string;
}
