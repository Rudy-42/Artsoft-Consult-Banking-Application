import {Component, OnInit} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Router} from '@angular/router';
import {AccountModel} from './account.model';

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css']
})
export class AccountComponent implements OnInit {
  hidden = true;
  account: AccountModel = new AccountModel();
  accounts: AccountModel[];
  currency;
  list;
  ok: boolean;

  constructor(private http: HttpClient, private router: Router) {
  }

  ngOnInit() {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        token: window.localStorage.getItem('token')
      })
    };
    this.http.get<AccountModel[]>('http://localhost:8080/users/getAccounts',
      httpOptions).subscribe(result => {
        console.table(result);
        this.accounts = result;
        console.table(this.accounts);
      },
      error => console.log(error));
    this.hidden = false;
  }

  check(): boolean {
    this.ok = true;
    this.accounts.forEach(value => {
      if (value.currency === (this.currency.options[this.currency.selectedIndex].value.toString())) {
        this.ok = false;
      }
    });
    if (this.ok) {
      return true;
    } else {
      return false;
    }
  }

  do() {
    this.currency = (document.getElementById('currency')) as HTMLSelectElement;
    // console.log(this.currency.options[this.currency.selectedIndex].value);
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        token: window.localStorage.getItem('token')
      })
    };
    if (this.check()) {
      this.http.post<string>('http://localhost:8080/users/addAccount',
        this.currency.options[this.currency.selectedIndex].value.toString(),
        httpOptions).subscribe(
        result => {
          console.log(result);
          alert('Account added');
        },
        error => console.log(error));

    } else {
      alert('Account already exists');
    }
  }

  menu() {
    this.router.navigateByUrl('/welcome');
  }
}
