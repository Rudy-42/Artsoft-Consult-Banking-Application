export class UserModel {
  name: string;
  phoneNumber: string;
  email: string;
  address: string;
  cnp: string;
}
