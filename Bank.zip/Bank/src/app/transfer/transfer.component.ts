import {Component, OnInit} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Router} from '@angular/router';
import {TransferModel} from './transfer.model';
import {AccountModel} from '../account/account.model';
import {MakeTransferModel} from './makeTransfer.model';

@Component({
  selector: 'app-transfer',
  templateUrl: './transfer.component.html',
  styleUrls: ['./transfer.component.css']
})
export class TransferComponent implements OnInit {
  hidden = true;
  transfers: TransferModel[];
  accounts: AccountModel[];
  currency;
  makeTransfer: MakeTransferModel = new MakeTransferModel();
  type;
  ok: boolean;

  constructor(private http: HttpClient, private router: Router) {
  }

  ngOnInit() {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        token: window.localStorage.getItem('token')
      })
    };
    this.http.get<TransferModel[]>('http://localhost:8080/users/getTransfers',
      httpOptions).subscribe(result => {
        this.transfers = result;
        console.table(this.transfers);
      },
      error => console.log(error));
    this.http.get<AccountModel[]>('http://localhost:8080/users/getAccounts',
      httpOptions).subscribe(result => {
        this.accounts = result;
        console.table(this.accounts);
      },
      error => console.log(error));
    this.hidden = false;
  }
  do() {
    this.currency = (document.getElementById('account')) as HTMLSelectElement;
    // console.log(this.currency.options[this.currency.selectedIndex].value);
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        token: window.localStorage.getItem('token')
      })
    };
    if (true) {
      this.makeTransfer.fromId = this.currency.options[this.currency.selectedIndex].text.toString();
      this.http.post<string>('http://localhost:8080/users/makeTransfer', this.makeTransfer,
        httpOptions).subscribe(
        result => {
          console.log(result);
        },
        error => console.log(error));
      alert('Done');
    } else {
      alert('Error');
    }
  }

  menu() {
    this.router.navigateByUrl('/welcome');
  }
}
