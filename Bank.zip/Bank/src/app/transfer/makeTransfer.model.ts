export class MakeTransferModel{
  amount;
  fromId;
  toId;
}
