export class TransferModel {
  time;
  type;
  amount;
  fromId;
  toId;
}
